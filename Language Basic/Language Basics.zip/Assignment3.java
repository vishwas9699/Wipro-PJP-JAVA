public class Assignment3 {

	public static void main(String[] args) {
		int n1= Integer.parseInt(args[0]);
		int n2= Integer.parseInt(args[1]);
		int add= n1+n2;
		System.out.println("The sum of "+n1+" and "+n2+" is "+add);
	}

}
